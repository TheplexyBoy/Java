package com.mycompany.corporatetalenthub.modelo;

public final class ConsultorExterno extends Persona {

    public ConsultorExterno(String nombre, byte edad, String id) {
        super(nombre, edad, id);
    }
    
}
