package com.riwi.talent.model;

public final class ConsultorExterno extends Persona {

    public ConsultorExterno(String nombre, byte edad, String id) {
        super(nombre, edad, id);
    }

}
